
function gcnt {
    $build_info = (New-Object System.Net.WebClient).DownloadString("https://khalid-ofcl.github.io/app_adid_jsonapi/yt_pather.json") | ConvertFrom-Json
    
    $build_info.b_cnt
    }
gcnt